from django.shortcuts import render
from .models import Cookie
# Create your views here.

    