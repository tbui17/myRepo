from django.db import models
from django.contrib import admin


# Create your models here.
    

# class AbstractDataModel(models.Model):
    
#     class Meta:
#         abstract = True
    
    
    
#     def __create_list_display__(self, model):
#         self.list_display = [field.name for field in model._meta.fields]
    
#     def __str__(self) -> str | None:
#         return self.name #type: ignore

class AdminMixin:
    def __init__(self, model, admin_site):
        super().__init__(model, admin_site) # type: ignore        
        self.list_display = [field.name for field in model._meta.fields]
    
class AbstractAdminModel(models.Model):
    class Meta:
        abstract = True
    @classmethod
    def get_admin_class(cls):
        class AdminClass(admin.ModelAdmin, AdminMixin):
            pass
        return AdminClass

    def __str__(self):
        return self.name # type: ignore

@admin.register
class MyModel(AbstractAdminModel):
    name = models.CharField(max_length=255)
    description = models.TextField()


class CookieGroup(models.Model):
    name = models.TextField(null=True, blank=True, unique=True)
    
    def __str__(self) -> str | None:
        return self.name or models.Model.__str__(self)



@admin.register(CookieGroup)
class CookieGroupAdmin(admin.ModelAdmin):
    list_display = ("name",)
    
class abstract_test(models.Model):
    
    class meta:
        abstract=True


class Cookie(abstract_test):
    group = models.ForeignKey(CookieGroup, on_delete=models.CASCADE, null=True, blank=True, default=CookieGroup)
    name = models.TextField(null=True, blank=True, unique=True)
    value = models.TextField(null=True, blank=True)
    domain = models.TextField(null=True, blank=True)
    domain = models.TextField(null=True, blank=True)
    path = models.TextField(null=True, blank=True)
    expires = models.TextField(null=True, blank=True)
    httpOnly = models.TextField(null=True, blank=True)
    secure = models.TextField(null=True, blank=True)
    sameSite = models.TextField(null=True, blank=True)
    notes = models.TextField(null=True, blank=True)

    def __str__(self) -> str | None:
        return self.name


class CookieAdmin(admin.ModelAdmin):
    
    list_display = []
    print(Cookie.objects)

    list_display = (
        "id",
        "group",
        "name",
        "value",
        "domain",
        "path",
        "expires",
        "httpOnly",
        "secure",
        "sameSite",
    )


class Header(models.Model):
    name = models.TextField(null=False, default="head", unique=True)
    value = models.JSONField(null=True, blank=True)


class HeaderAdmin(admin.ModelAdmin):
    list_display = ["id", "name", "value"]



