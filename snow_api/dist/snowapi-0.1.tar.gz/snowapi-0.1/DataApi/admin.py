from django.contrib import admin

# Register your models here.
from .models import Cookie, CookieAdmin, Header, HeaderAdmin


admin.site.register(Cookie, CookieAdmin)
admin.site.register(Header, HeaderAdmin)