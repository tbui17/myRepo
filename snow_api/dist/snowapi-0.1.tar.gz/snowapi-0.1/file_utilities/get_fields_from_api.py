from resources.request_setup import TaskApiWorker

worker: TaskApiWorker = TaskApiWorker(table_name="sn_customerservice_case")

entries = worker.get_by_number("CS0001001")
fields = entries.items()
import json, os

page_dir_path = "resources/pages"
python_file_name = "dev_cs_fields2.py"


os.chdir(page_dir_path)

with open(python_file_name, "w") as f:
    sortlist = [k for k, v in fields]
    sortlist.sort()
    for u in sortlist:
        f.write(f'{u.upper()}="{u}"\n')
print(f"{python_file_name} successfully written to {os.getcwd()}")
