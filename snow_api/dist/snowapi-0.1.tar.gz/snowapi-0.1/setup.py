import setuptools

setuptools.setup(
    name="snowapi",
    version="0.1",
    packages=setuptools.find_packages(),
    zip_safe=False
)
