import requests


def show_three():
    return 3
