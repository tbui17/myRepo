from typing import Any
from playwright.sync_api import sync_playwright
from playwright import sync_api
from configs import uconfigs

import os
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'database.settings')
import django
django.setup()
from DataApi.models import Cookie, Header


def get_auth_and_cookies() -> Any:
    domain_name = uconfigs.base_url
    portNumber: str = "9222"

    with sync_playwright() as playwright:
        browser = playwright.chromium.connect_over_cdp(f"http://localhost:{portNumber}")

        context = browser.contexts[0]

        all_cookies = context.cookies()
        snow_cookies = [
            cookie for cookie in all_cookies if cookie["domain"] in domain_name
        ]
        cookies_dict = {
            cookie_entry["name"]: cookie_entry["value"] for cookie_entry in snow_cookies
        }
        snow_page: sync_api.Page = [
            page for page in context.pages if domain_name in page.url
        ][0]
        try:
            g_ck = snow_page.evaluate("g_ck")
        except ReferenceError:
            print(
                "g_ck not defined selected page for playwright cdp may not be snow page"
            )

    
    headers_dict = {
        "X-UserToken": g_ck,
        "content-type": "application/json",
        "accepts": "application/json",
    }
    
    headers = Header(name=headers,value=headers_dict)
    snow_cookies = Cookie.objects.create(
    name=cookies_dict.get('name'),
    value=cookies_dict.get('value'),
    domain=cookies_dict.get('domain'),
    path=cookies_dict.get('path'),
    expires=cookies_dict.get('expires'),
    httpOnly=cookies_dict.get('httpOnly'),
    secure=cookies_dict.get('secure'),
    sameSite=cookies_dict.get('sameSite'),
)