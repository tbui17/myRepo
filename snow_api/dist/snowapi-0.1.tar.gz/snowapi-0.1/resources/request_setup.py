import logging
from typing import Any, cast
import requests
from .data_types import FieldResp
from .common_utils import regex_email
from .pages.table_enumerators import (
    TableEnums as tbl,
    ResponseEnums as RE1,
    ApiUrlsEnums as ae,
)

# from dataclasses import field, dataclass
from pydantic import Field, BaseModel
from pydantic.dataclasses import dataclass
from requests import Response, Session
from requests.utils import cookiejar_from_dict
from requests.cookies import RequestsCookieJar
import logging
from configs import uconfigs as cfg


base_url: str = cfg.base_url
default_params: dict = dict(cfg.default_params_post)
dict_cookies: dict = dict(sdf)
default_cookies: RequestsCookieJar = cookiejar_from_dict(dict_cookies)
default_headers: dict = dict(qwe)
email_api: str = cfg.email_api


def create_session() -> Session:
    session: Session = Session()
    session.cookies.update(default_cookies)
    session.headers = dict(default_headers)
    return session


class GeneralApiWorker(BaseModel):
    session: Any = Field(default_factory=lambda: create_session())
    cache: dict = Field(default_factory=lambda: {})
    _domain: str = base_url

    def provide_defaults(self):
        return {
            "params": dict(default_params),
            "cookies": dict(default_cookies),
            "headers": dict(default_headers),
        }

    def provide_CnH(self):
        return {"cookies": dict(default_cookies), "headers": dict(default_headers)}

    def req(
        self, method: str, url: str, params=default_params, **kwargs
    ) -> dict | list:
        "Accepts all kwargs a session.request would need"
        response: Response = self.session.request(
            method=method, url=url, params=params, **kwargs
        )
        response.raise_for_status()
        json_data: dict = response.json()
        json_results: dict | list = json_data[RE1.RESULT]
        return json_results

    def single_req(
        self, method: str, url: str, params=default_params, **kwargs
    ) -> dict:
        "Accepts all kwargs a session.request would need"
        json_results: dict | list = self.req(
            method=method, url=url, params=params, **kwargs
        )
        if type(json_results) == list:
            result: dict = json_results[0]
            return result
        return cast(dict, json_results)


class TableApiWorker(GeneralApiWorker):
    ...


class TaskApiWorker(TableApiWorker):
    table_name: str = tbl.TASK

    def get_by_number(self, number: str, **kwargs) -> dict[str, FieldResp]:
        "Accepts all kwargs a session.request would need"
        if cached_id := self.cache.get("number"):
            url1: str = f"{base_url}/api/now/table/{self.table_name}/{cached_id}"
            return self.single_req(method="GET", url=url1)
        else:
            url1: str = f"{base_url}/api/now/table/{self.table_name}"
            return self.single_req(method="GET", url=url1, params={"number": number})

    def method_by_id(
        self, method: str, number: str, body: dict, **kwargs
    ) -> dict[str, FieldResp]:
        "Use a specified HTTP method. Case insensitive. Accepts all kwargs a session.request would need"
        url1: str = f"{base_url}/api/now/table/{self.table_name}"
        return self.single_req(method=method.upper(), url=url1, **kwargs)

    def method_by_number(
        self, method: str, number: str, body: dict, **kwargs
    ) -> dict[str, FieldResp]:
        """
        GETS a task record by number, gets its ID, then uses method_by_id with the specified method.
        Use a specified HTTP method.
        Case insensitive.
        Accepts all kwargs a session.request would need
        """
        url1: str = f"{base_url}/api/now/table/{self.table_name}"
        return self.single_req(
            method=method.upper(), url=url1, params={"number": number}, **kwargs
        )


# class mailMixin:
#     def send_mail(
#         self, number: str, message: str, **kwargs
#     ) -> dict[str, FieldResp] | None:
#         self.params = dict(default_params)
#         entry: dict[str, FieldResp] = self.get_by_number(number)
#         regex_results: tuple | None = regex_email(entry["description"]["value"])
#         if not regex_results:
#             logging.warning(msg="No emails were found in the body.", exc_info=True)
#             return
#         else:
#             to, cc = regex_results
#         self.url = f"{base_url}{email_api}"
#         body: dict[str, str] = {
#             "number": entry["number"]["value"],
#             "to": to,
#             "cc": cc,
#             "subject": f"{entry['number']['value']} - {entry['short_description']['value']}",
#             "message": f"{message}",
#         }
#         resp: Response = requests.post(
#             url=self.url,
#             params=None,
#             cookies=self.cookies,
#             headers=self.headers,
#             json=body,
#         )
#         self.validate_response(resp)
#         json_info = resp.json()
#         return self.get_entry_info(json_info)

#     def attach_kb(
#     self, kb_number: str, task_number: str, **kwargs
# ) -> dict[str, FieldResp]:

#     body: dict[str, str] = {"kb_knowledge": kb_number, "task": task_number}
#     m2m_kb_url: str = f"{base_url}/api/now/table/{tbl.M2M_KB_TASK}"

#     self.method
