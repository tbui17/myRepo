import json
from pathlib import Path
import re
from re import Pattern
from typing import LiteralString, Any
import configs.uconfigs as cfg


def regex_email(data: str) -> tuple[str, LiteralString] | None:
    filters: list = cfg.filters
    for filter in filters:
        data.replace(filter, "")
    regexsyntax: Pattern[str] = re.compile(
        r"""
        [a-zA-Z0-9_.]+ #username
        @ #@ symbol
        [a-zA-Z0-9_.]+ #domain name
        """,
        re.VERBOSE,
    )
    if not (regexresults := regexsyntax.findall(data)):
        return None
    CCList: LiteralString = ",".join(regexresults)
    return regexresults[0], CCList
